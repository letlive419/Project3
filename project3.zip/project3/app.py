from flask import Flask, render_template, request, url_for
from flask_pymongo import PyMongo
from flask_wtf import FlaskForm
from wtforms import StringField, DecimalField, SelectField,DateField


app = Flask(__name__)
app.config["SECRET_KEY"]="Cop4813"
app.config["MONGO_URI"] ="mongodb+srv://ecruz107:cop@learningmongodb.tnwfj.mongodb.net/db?ssl=true&ssl_cert_reqs=CERT_NONE"
mongo = PyMongo(app)



class Expenses(FlaskForm):
   description = StringField('Enter Description')
   category = SelectField('Categories', choices=[
       ("Gas" , "Gas"),("Laundry","Laundry"),("Insurance","Insurance"),("Groceries","Groceries"),("Books","Books"),("Movies","Movies"),("Clothes","Clothes"),
       ("Decorations","Decorations")

   ])
   cost = DecimalField('cost')
   date = DateField('DatePicker', format='%dd-mm-YYYY')

def get_total_expenses(category):
    cat = mongo.db.expenses.find({"category":category})
    total = 0
    for i in cat:
        total += float(i["cost"])
    return total





@app.route('/')
def index():
    my_expenses = mongo.db.expenses.find()
    total_cost=0
    lstCategories = ["Gas","Laundry","Insurance","Groceries","Books","Movies","Clothes",
       "Decorations"]
    expensesByCategory =[]
    for i in my_expenses:
        total_cost+=float(i["cost"])

    for i in lstCategories:
        expensesByCategory.append([(i,get_total_expenses(i))])


    return render_template('index.html', expenses=total_cost, expensesByCategory=expensesByCategory)


@app.route('/addExpenses',methods=["GET","POST"])
def addExpenses():
    expensesForm = Expenses(request.form)
    if request.method == "POST":
        description = request.form['description']
        category = request.form['category']
        cost = request.form['cost']
        date = request.form['date']
        insert_into_db={"description":description, "category":category,"cost":cost,"date":date}
        mongo.db.expenses.insert_one(insert_into_db)

        return render_template("expenseAdded.html")
    return render_template("addExpenses.html",form=expensesForm)


app.run(debug=True,port=8080)